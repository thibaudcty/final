
import pygame as pg



class ResourceManager:


    def __init__(self):

        # resources
        self.resources = {
            "wood": 100,
            "stone": 100,
            "food":100
        }

        #costs
        self.costs = {
            "Towncenter": {"wood": 7, "stone": 3},
            "House": {"wood": 3, "stone": 5 , "food":5},
            "castle": {"wood": 3, "stone": 2, "food":1},
            "moulin": {"wood": 7, "stone":4, "food":1},


        }

    def apply_cost_to_resource(self, building):
        for resource, cost in self.costs[building].items():
            self.resources[resource] -= cost

    def is_affordable(self, building):
        print("there's enough resources")
        for resource, cost in self.costs[building].items():
            if cost > self.resources[resource]:
                print("there's no enough resources")
                exit(1)


