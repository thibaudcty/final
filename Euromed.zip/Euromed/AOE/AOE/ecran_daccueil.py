
import tkinter
import pygame 
from tkinter import *
from game import *
from tkinter import ttk

from PIL import ImageTk
from definitions import *
import main


def fonction_menu_principal() :

    
    fen1=Tk()
    fen1.title("Menu Principal")
    fen1.geometry("1080x800")
    fen1.resizable(width=False,height=False)
  
    graphe=Canvas(fen1, width=1080, height=800,bg="gray")

   
    img = PhotoImage(file="ecran.GIF").zoom(1,1)
    graphe.create_image(500,405, image=img)
    graphe.pack()


    newgame=Button(fen1, text='New Game', bg="gray", width=15, height=3, font='arial', command=lambda: fonction_jeu(fen1))
    newgame.place(x=30, y=140)

    exit=Button(fen1, text='Quit', bg="gray", width=15, height=3, font='arial', command=lambda: fonction_quit(fen1))
    pygame.quit()
    exit.place(x=30, y=710)

    fen1.mainloop()


def fonction_jeu(fen):
    fen.destroy()
    main.main()

def fonction_quit(fen) :
    fen.destroy()
    pygame.quit()

fonction_menu_principal()